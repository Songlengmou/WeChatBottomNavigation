package com.anningtex.wechatbottomnavigation.fragment;

/**
 * @author Administrator
 */
public class FindFragment extends BaseFragment {

}
