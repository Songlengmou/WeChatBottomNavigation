package com.anningtex.wechatbottomnavigation.fragment;

/**
 * @author Administrator
 */
public class ContactFragment extends BaseFragment {

}
