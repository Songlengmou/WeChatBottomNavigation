package com.anningtex.wechatbottomnavigation.fragment;

/**
 * @author Administrator
 */
public class ChatFragment extends BaseFragment {

}
