package com.anningtex.wechatbottomnavigation.fragment;

/**
 * @author Administrator
 */
public class ProfileFragment extends BaseFragment {

}
